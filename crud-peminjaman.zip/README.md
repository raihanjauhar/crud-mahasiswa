# Sistem Informasi Peminjaman Buku Digital
Aplikasi sederhana CRUD untuk mencatat peminjaman buku perpustakaan digital. Dibuat dengan PHP & MySQLi.
