<?php include 'config/koneksi.php';
$id = $_GET['id'];
$data = mysqli_fetch_array(mysqli_query($koneksi, "SELECT * FROM peminjaman WHERE id='$id'"));
?>
<!DOCTYPE html>
<html>
<head><title>Edit Peminjaman</title></head>
<body>
<h2>Edit Peminjaman Buku</h2>
<form method="post">
    Nama: <input type="text" name="nama" value="<?= $data['nama'] ?>"><br>
    Judul Buku: <input type="text" name="judul_buku" value="<?= $data['judul_buku'] ?>"><br>
    Tanggal Pinjam: <input type="date" name="tanggal_pinjam" value="<?= $data['tanggal_pinjam'] ?>"><br>
    <input type="submit" name="update" value="Update">
</form>
<?php
if(isset($_POST['update'])){
    mysqli_query($koneksi, "UPDATE peminjaman SET nama='$_POST[nama]', judul_buku='$_POST[judul_buku]',
        tanggal_pinjam='$_POST[tanggal_pinjam]' WHERE id='$id'");
    echo "<script>location='index.php'</script>";
}
?>
</body>
</html>