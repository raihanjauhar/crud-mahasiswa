
CREATE DATABASE IF NOT EXISTS perpustakaan;
USE perpustakaan;

CREATE TABLE peminjaman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100),
    judul_buku VARCHAR(200),
    tanggal_pinjam DATE
);
