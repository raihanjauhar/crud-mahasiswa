<?php
include 'config/koneksi.php';
$data = mysqli_query($koneksi, "SELECT * FROM peminjaman");
?>
<!DOCTYPE html>
<html>
<head><title>Data Peminjaman Buku</title></head>
<body>
<h2>Data Peminjaman Buku</h2>
<a href="tambah.php">+ Tambah Data</a>
<table border="1" cellpadding="10" cellspacing="0">
    <tr><th>No</th><th>Nama</th><th>Judul Buku</th><th>Tanggal Pinjam</th><th>Aksi</th></tr>
    <?php $no=1; while($d = mysqli_fetch_array($data)){ ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= $d['nama'] ?></td>
        <td><?= $d['judul_buku'] ?></td>
        <td><?= $d['tanggal_pinjam'] ?></td>
        <td>
            <a href="edit.php?id=<?= $d['id'] ?>">Edit</a> |
            <a href="hapus.php?id=<?= $d['id'] ?>" onclick="return confirm('Hapus data?')">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>
</body>
</html>