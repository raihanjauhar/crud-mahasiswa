<?php include 'config/koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head><title>Tambah Peminjaman</title></head>
<body>
<h2>Tambah Peminjaman Buku</h2>
<form method="post">
    Nama: <input type="text" name="nama"><br>
    Judul Buku: <input type="text" name="judul_buku"><br>
    Tanggal Pinjam: <input type="date" name="tanggal_pinjam"><br>
    <input type="submit" name="simpan" value="Simpan">
</form>
<?php
if(isset($_POST['simpan'])){
    mysqli_query($koneksi, "INSERT INTO peminjaman (nama, judul_buku, tanggal_pinjam)
        VALUES ('$_POST[nama]', '$_POST[judul_buku]', '$_POST[tanggal_pinjam]')");
    echo "<script>location='index.php'</script>";
}
?>
</body>
</html>